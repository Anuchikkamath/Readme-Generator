# Pirr

## Project Overview
Pirr is a software project aimed at enhancing user engagement through a robust platform that manages subscriptions, premium features, and user interactions. The application focuses on providing seamless experiences for both free and premium users, integrating functionalities such as word generation, tracking, and subscription management. The project leverages modern technologies to ensure a responsive and efficient user interface, while also addressing backend complexities.

## Problem Statement
Pirr addresses the need for a comprehensive solution that manages user subscriptions and enhances communication within the team. It aims to mitigate issues related to user token expirations, planned leaves, and performance bottlenecks, ensuring a smooth user experience and efficient project management. By implementing structured communication and logging practices, Pirr seeks to improve overall project transparency and accountability.

## Requirements Summary
- **User Management**: Develop solutions for token expirations, user migration due to schema changes, and background jobs for updating user types.
- **Subscription Features**: Implement premium user functionalities, subscription management, free trial options, and custom email notifications.
- **Performance and Reliability**: Enhance app performance, resolve crashing issues, and ensure effective logging of working hours.
- **Communication Tools**: Establish guidelines for timely communication and documentation to improve team collaboration and client interactions.
- **Task Management**: Create a structured approach for task estimation, testing, and bug resolution, including a clear breakdown of tasks and responsibilities.

## Tech Stack
- **Frontend**: Flutter
- **Backend**: Firebase
- **Collaboration Tools**: Slack, Excel
- **Version Control**: Git (feature branches, pull requests)
- **Deployment**: Staging environments for testing and validation

## Key Discussions
Throughout the project, there has been a strong emphasis on proactive communication and the importance of logging hours for transparency. Discussions have highlighted the need to clarify task distinctions and segregate tasks for better tracking. The team has also focused on refining the user experience through backend logic improvements and ensuring that premium features are well-integrated. Performance issues, particularly related to app responsiveness and crashing, have been recurring themes that require ongoing attention.

## Decisions & Outcomes
Key decisions made include the adoption of Firebase as the backend service due to its scalability and ease of integration with Flutter. The team decided to implement a structured approach to task management, including the introduction of a 'questions' column for clarifications and a focus on closing tasks daily. Additionally, the decision to prioritize bug fixes and performance improvements has shaped the current development focus.

## Blockers & Risks
Current blockers include delays in client communication and last-minute leave announcements that disrupt planning. There are also pending updates related to deep linking configurations and concerns about app crashing in staging environments. Risks associated with data loss due to changing event names and unresponsiveness affecting user experience have been identified.

## Current Status
The project is in a development phase with ongoing efforts to resolve performance issues and finalize subscription functionalities. The team is actively working on cleaning up the codebase and preparing for upcoming client interactions.

## Open Questions / Next Steps
- Clarification needed on the specifics of premium user word expiration and additional word purchases.
- Further investigation into app crashing issues and memory leaks.
- Finalize the timeline for Figma designs and ensure all tasks are updated accordingly.
- Prepare documentation for known issues and testing efforts to enhance project transparency.