"""
FastAPI Backend Entry Point
README Generator API
"""

from fastapi import FastAPI
from app.api.project_routes import router as project_router

app = FastAPI(
    title="README Generator API",
    description="API for syncing emails, managing projects, and generating README files",
    version="1.0.0",
    tags_metadata=[
        {
            "name": "projects",
            "description": "Operations related to project management, syncing, and README generation.",
        },
    ]
)

# Include routers
app.include_router(project_router)


@app.get("/")
async def root():
    """Root endpoint."""
    return {"message": "README Generator API", "version": "1.0.0"}


@app.get("/health")
async def health():
    """Health check endpoint."""
    return {"status": "healthy"}
