"""
PostgreSQL Client Module
Manages database connections and operations for storing meeting notes.
Handles dynamic table creation, schema evolution, and cleanup of old tables.
"""

import psycopg2
from typing import Dict, List, Optional, Tuple
from schema_manager import SchemaManager
from app.services.project_resolver import ProjectResolver
import os
from dotenv import load_dotenv

load_dotenv()


class PostgresClient:
    """Client for PostgreSQL database operations."""
    
    def __init__(self):
        """Initialize PostgreSQL client."""
        self.schema_manager = SchemaManager()
        
        # Ensure database exists FIRST (before anything tries to connect)
        self._ensure_database_exists()
        
        # Ensure metadata table has correct schema (migrates old schema if needed)
        self.schema_manager.ensure_metadata_table_exists()
        
        # NOW initialize project resolver (it may query the DB)
        self.project_resolver = ProjectResolver()
    
    def get_connection(self):
        """
        Get PostgreSQL connection.
        
        Returns:
            psycopg2.connection: Database connection
        """
        return psycopg2.connect(
            host=os.getenv('DB_HOST', 'localhost'),
            port=os.getenv('DB_PORT', '5432'),
            user=os.getenv('DB_USER', 'postgres'),
            password=os.getenv('DB_PASSWORD', ''),
            database=os.getenv('DB_NAME', 'projects')
        )
    
    def _ensure_database_exists(self):
        """
        Create the 'projects' database if it doesn't exist.
        Connects to admin database to create the target database.
        """
        import psycopg2.extensions
        from psycopg2 import sql
        
        db_name = os.getenv('DB_NAME', 'projects')
        admin_db = os.getenv('DB_ADMIN_DB', 'postgres')
        
        try:
            # Connect to admin database to create target database
            admin_conn = psycopg2.connect(
                host=os.getenv('DB_HOST', 'localhost'),
                port=os.getenv('DB_PORT', '5432'),
                user=os.getenv('DB_USER', 'postgres'),
                password=os.getenv('DB_PASSWORD', ''),
                database=admin_db
            )
            admin_conn.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)
            admin_cursor = admin_conn.cursor()
            
            # Check if database exists
            admin_cursor.execute(
                "SELECT 1 FROM pg_database WHERE datname = %s",
                (db_name,)
            )
            
            exists = admin_cursor.fetchone()
            
            if not exists:
                # Create database
                admin_cursor.execute(
                    sql.SQL("CREATE DATABASE {}").format(
                        sql.Identifier(db_name)
                    )
                )
                print(f"[OK] Created database: {db_name}")
            
            admin_cursor.close()
            admin_conn.close()
            
        except Exception as e:
            print(f"[WARN] Could not ensure database exists: {e}")
    
    def insert_meeting_note(self, email_subject: str, data: dict, 
                           llm_extracted_project: Optional[str] = None):
        """
        Insert structured meeting note data into the canonical project's table.
        Uses learning-based project resolution to ensure one table per project.
        
        Args:
            email_subject: Email subject line (for project resolution)
            data: Dictionary with meeting note data (from LLM JSON)
            llm_extracted_project: Optional project name from LLM extraction
        """
        # Resolve canonical project using learning-based approach
        canonical_name, normalized_name = self.project_resolver.resolve_canonical_project(
            email_subject, llm_extracted_project
        )
        
        # Extract context from subject
        context = self.project_resolver.extract_context_from_subject(
            email_subject, canonical_name
        )
        
        # Add context to data if found
        if context:
            data['meeting_context'] = context
        
        # Get all keys from data (excluding reserved keys)
        json_keys = [k for k in data.keys() 
                     if k.lower() not in ['id', 'created_at', 'project_name', 'canonical_name']]
        
        # Ensure table exists and has all needed columns
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT column_name 
                FROM information_schema.columns 
                WHERE table_name = %s
            """, (normalized_name,))
            
            existing_columns = {row[0].lower() for row in cursor.fetchall()}
            cursor.close()
            conn.close()
            
            if not existing_columns:
                # Table doesn't exist - create it
                self.schema_manager.create_project_table(normalized_name, json_keys)
            else:
                # Table exists - check for new columns
                existing_keys = {col.lower() for col in existing_columns}
                new_keys = [k for k in json_keys 
                          if self.schema_manager._sanitize_column_name(k).lower() not in existing_keys]
                
                if new_keys:
                    self.schema_manager.alter_table_add_columns(normalized_name, new_keys)
        
        except psycopg2.errors.UndefinedTable:
            self.schema_manager.create_project_table(normalized_name, json_keys)
        
        # Insert data
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            # Prepare columns and values
            columns = []
            values = []
            placeholders = []
            
            # Handle meeting_date - convert None/"None" to NULL
            meeting_date = data.get('meeting_date')
            if meeting_date is None or str(meeting_date).strip().lower() in ['none', '']:
                meeting_date = None
            else:
                meeting_date_str = str(meeting_date).strip()
                if meeting_date_str and meeting_date_str.lower() != 'none':
                    meeting_date = meeting_date_str
                else:
                    meeting_date = None
            
            columns.append('meeting_date')
            values.append(meeting_date)
            placeholders.append('%s')
            
            # Add other columns from data
            for key, value in data.items():
                if key.lower() in ['id', 'meeting_date', 'created_at', 'project_name', 'canonical_name']:
                    continue
                
                safe_key = self.schema_manager._sanitize_column_name(key)
                columns.append(safe_key)
                
                # Handle None values properly
                if value is None or str(value).strip().lower() in ['none', '']:
                    processed_value = None
                elif isinstance(value, (dict, list)):
                    import json
                    processed_value = json.dumps(value)
                else:
                    processed_value = str(value)
                
                values.append(processed_value)
                placeholders.append('%s')
            
            # Build INSERT statement
            columns_str = ', '.join([f'"{col}"' for col in columns])
            placeholders_str = ', '.join(placeholders)
            
            insert_sql = f"""
                INSERT INTO "{normalized_name}" ({columns_str}, created_at)
                VALUES ({placeholders_str}, CURRENT_TIMESTAMP)
                ON CONFLICT DO NOTHING;
            """
            
            cursor.execute(insert_sql, values)
            conn.commit()
            
            print(f"[OK] Stored meeting note in table: {normalized_name}")
            
        except Exception as e:
            conn.rollback()
            print(f"[ERROR] Error inserting data: {e}")
            raise
        finally:
            cursor.close()
            conn.close()
    
    def get_all_projects(self) -> List[str]:
        """
        Get list of all registered canonical projects.
        
        Returns:
            list: List of canonical project names
        """
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT canonical_name, normalized_name 
                FROM projects_metadata 
                ORDER BY canonical_name
            """)
            projects = cursor.fetchall()
            cursor.close()
            conn.close()
            return projects
        except Exception as e:
            print(f"[WARN] Could not fetch projects: {e}")
            return []
    
    def fetch_project_data(self, table_name: str) -> Tuple:
        """
        Fetch all rows from a project table, ordered chronologically.

        Args:
            table_name: Normalized table name (e.g. 'act')

        Returns:
            tuple: (columns: List[str], rows: List[Dict])
        """
        conn = self.get_connection()
        cursor = conn.cursor()

        try:
            # Get column names
            cursor.execute("""
                SELECT column_name
                FROM information_schema.columns
                WHERE table_name = %s
                ORDER BY ordinal_position
            """, (table_name,))
            columns = [row[0] for row in cursor.fetchall()]

            if not columns:
                raise ValueError(f"Table '{table_name}' does not exist or has no columns.")

            # Fetch all rows, ordered by meeting_date then created_at
            cursor.execute(
                f'SELECT * FROM "{table_name}" '
                f'ORDER BY meeting_date ASC NULLS LAST, created_at ASC'
            )
            raw_rows = cursor.fetchall()

            # Convert to list of dicts
            rows = []
            for raw in raw_rows:
                row_dict = {}
                for i, col in enumerate(columns):
                    val = raw[i]
                    # Convert date/datetime to string for serialization
                    if hasattr(val, 'isoformat'):
                        val = val.isoformat()
                    row_dict[col] = val
                rows.append(row_dict)

            return columns, rows

        finally:
            cursor.close()
            conn.close()

    def project_table_exists(self, table_name: str) -> bool:
        """
        Check if a project table exists in the database.

        Args:
            table_name: Normalized table name

        Returns:
            bool: True if table exists
        """
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("""
                SELECT 1 FROM information_schema.tables
                WHERE table_name = %s AND table_schema = 'public'
            """, (table_name,))
            return cursor.fetchone() is not None
        finally:
            cursor.close()
            conn.close()

    def store_readme(self, project_name: str, normalized_name: str,
                     content: str, model: str, meeting_count: int):
        """
        Store a generated README in the project_readmes table.

        Args:
            project_name: Canonical project name
            normalized_name: Normalized table name
            content: README markdown content
            model: LLM model used for generation
            meeting_count: Number of meetings used
        """
        # Ensure the readmes table exists
        self.schema_manager.ensure_readmes_table_exists()

        conn = self.get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute("""
                INSERT INTO project_readmes
                    (project_name, normalized_name, readme_content,
                     model_used, meeting_count)
                VALUES (%s, %s, %s, %s, %s)
            """, (project_name, normalized_name, content, model, meeting_count))

            conn.commit()
            print(f"[OK] README stored in database (project_readmes table)")

        except Exception as e:
            conn.rollback()
            print(f"[ERROR] Failed to store README in database: {e}")
            raise
        finally:
            cursor.close()
            conn.close()

    def list_project_tables(self) -> List[str]:
        """
        List all project tables (excluding metadata/system tables).

        Returns:
            list: List of table names
        """
        all_tables = self.schema_manager.get_all_table_names()
        system_tables = {'projects_metadata', 'project_readmes'}
        return [t for t in all_tables if t not in system_tables]

    def cleanup_old_tables(self, dry_run: bool = True) -> List[str]:
        """
        Find and optionally drop old fragmented tables that should have been
        consolidated into canonical project tables.
        
        For example, if canonical project "ACT" exists with table "act",
        old tables like "act_sync", "act_internal_discussion" are orphaned.
        
        Args:
            dry_run: If True, only list tables to drop. If False, actually drop them.
            
        Returns:
            list: List of orphaned table names
        """
        try:
            # Get all tables
            all_tables = self.schema_manager.get_all_table_names()
            
            # Get canonical project tables
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT normalized_name FROM projects_metadata")
            canonical_tables = {row[0] for row in cursor.fetchall()}
            cursor.close()
            conn.close()
            
            # Find orphaned tables (tables that are prefixed by a canonical table name)
            orphaned = []
            for table in all_tables:
                if table == 'projects_metadata':
                    continue
                
                # Check if this table is a canonical table
                if table in canonical_tables:
                    continue
                
                # Check if this table is an orphaned variant of a canonical table
                for canonical in canonical_tables:
                    if table.startswith(canonical + '_') and table != canonical:
                        orphaned.append(table)
                        break
            
            if orphaned:
                print(f"\nFound {len(orphaned)} orphaned table(s) from old fragmented resolution:")
                for table in orphaned:
                    print(f"  - {table}")
                
                if not dry_run:
                    print("\nDropping orphaned tables...")
                    self.schema_manager.drop_tables(orphaned)
                    print("[OK] Cleanup complete")
                else:
                    print("\n  Run with dry_run=False to drop these tables")
                    print("  Or run: python scripts/cleanup_old_tables.py")
            else:
                print("[OK] No orphaned tables found")
            
            return orphaned
            
        except Exception as e:
            print(f"[WARN] Error during cleanup: {e}")
            return []