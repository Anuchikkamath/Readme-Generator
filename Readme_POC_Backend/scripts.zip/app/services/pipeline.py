"""
Main Pipeline Script
Processes Gmail emails, extracts meeting notes, and stores them in PostgreSQL.
Groups emails by project and processes each project independently.
"""

import sys
import os
from typing import Dict, Optional, Any

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from app.services.ingestion.gmail_reader import GmailReader
from app.services.ingestion.body_parser import BodyParser
from documents.docs_reader import DocsReader
from app.services.llm.ollama_client import LLMClient
from app.services.storage.postgres_client import PostgresClient
from app.services.project_resolver import ProjectResolver


def sync() -> Dict[str, Any]:
    """
    Execute the sync pipeline.
    This function wraps the pipeline logic for API calls.
    
    Returns:
        dict: Status and summary of the sync operation
    """
    try:
        # Initialize clients
        gmail_reader = GmailReader()
        body_parser = BodyParser()
        docs_reader = DocsReader()
        llm_client = LLMClient()
        postgres_client = PostgresClient()
        project_resolver = ProjectResolver()
        
        # Fetch emails
        emails = gmail_reader.get_all_emails(query='Notes:')
        
        if not emails:
            return {
                "status": "sync completed",
                "message": "No emails found",
                "emails_fetched": 0,
                "meetings_stored": 0,
                "processed": 0,
                "skipped": 0
            }
        
        # Prepare emails for processing
        email_list = []
        for email in emails:
            subject = gmail_reader.get_subject(email)
            email_list.append({
                'email': email,
                'subject': subject
            })
        
        # Process each email
        total_processed = 0
        total_skipped = 0
        total_stored = 0
        
        for idx, email_data in enumerate(email_list, 1):
            email = email_data['email']
            subject = email_data['subject']
            
            # Extract document ID
            doc_id = body_parser.extract_notes_doc_id(email)
                
            if not doc_id:
                total_skipped += 1
                continue
            
            # Fetch document content
            try:
                title, content = docs_reader.fetch_notes_text(doc_id)
                
                if not content:
                    total_skipped += 1
                    continue
                
            except Exception as e:
                total_skipped += 1
                continue
            
            # Extract email date for meeting_date
            email_date = gmail_reader.get_date(email)
            
            # Extract structured data using LLM
            try:
                structured_data = llm_client.extract_structured_data(content, meeting_date=email_date)
                llm_project = structured_data.get('project_name')
                
            except Exception as e:
                total_skipped += 1
                continue
            
            # Store in database (uses canonical project resolution)
            try:
                postgres_client.insert_meeting_note(
                    email_subject=subject,
                    data=structured_data,
                    llm_extracted_project=llm_project
                )
                total_stored += 1
                total_processed += 1
                
            except Exception as e:
                total_skipped += 1
                continue
        
        return {
            "status": "sync completed",
            "emails_fetched": len(emails),
            "meetings_stored": total_stored,
            "processed": total_processed,
            "skipped": total_skipped
        }
        
    except Exception as error:
        return {
            "status": "sync failed",
            "error": str(error)
        }


def main():
    """Main pipeline execution (for CLI usage)."""
    print("=" * 60)
    print("Multi-Project Meeting Notes Processing Pipeline")
    print("=" * 60)
    
    result = sync()
    
    if result.get("status") == "sync failed":
        print(f"\n\nError in pipeline: {result.get('error')}")
        sys.exit(1)
    else:
        print(f"\n{'=' * 60}")
        print(f"Pipeline Summary")
        print(f"{'=' * 60}")
        print(f"Total emails fetched:        {result.get('emails_fetched', 0)}")
        print(f"Total meetings stored:        {result.get('meetings_stored', 0)}")
        print(f"Successfully processed:       {result.get('processed', 0)}")
        print(f"Skipped/failed:              {result.get('skipped', 0)}")
        print(f"{'=' * 60}")


if __name__ == "__main__":
    main()
