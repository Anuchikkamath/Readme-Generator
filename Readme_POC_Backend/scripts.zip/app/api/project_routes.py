"""
Project API Routes
Handles project-related endpoints for sync and README generation.
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, Any

from app.services.pipeline import sync
from app.services.storage.postgres_client import PostgresClient
from app.services.llm.readme_generator import ReadmeGenerator

router = APIRouter(
    prefix="",
    tags=["projects"],
    responses={404: {"description": "Not found"}}
)


class GenerateReadmeRequest(BaseModel):
    """Request model for README generation."""
    project_id: str
    start_date: Optional[str] = None
    end_date: Optional[str] = None


@router.post("/sync", summary="Sync emails and process meeting notes")
async def sync_endpoint():
    """
    Sync endpoint - runs the pipeline to process emails and store meeting notes.
    
    This endpoint:
    - Fetches emails from Gmail with 'Notes:' query
    - Extracts Google Docs links from emails
    - Processes documents and extracts structured data using LLM
    - Stores meeting notes in the database
    
    Returns:
        dict: Status and summary of the sync operation including:
            - status: "sync completed" or "sync failed"
            - emails_fetched: Number of emails processed
            - meetings_stored: Number of meetings stored
            - processed: Number successfully processed
            - skipped: Number skipped/failed
    """
    try:
        result = sync()
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Sync failed: {str(e)}")


@router.get("/projects", summary="Get all available projects")
async def get_projects():
    """
    Get all available projects from the database.
    
    Returns:
        dict: List of projects with canonical and normalized names
    """
    try:
        postgres_client = PostgresClient()
        projects = postgres_client.get_all_projects()
        
        project_list = []
        if projects:
            for canonical, normalized in projects:
                project_list.append({
                    "canonical_name": canonical,
                    "normalized_name": normalized
                })
        
        return {"projects": project_list}
    except Exception as e:
        # Return empty list on error to maintain API contract
        return {"projects": []}


@router.post("/generate-readme", summary="Generate README for a project")
async def generate_readme(request: GenerateReadmeRequest):
    """
    Generate README for a project by aggregating meeting data.
    
    This endpoint:
    - Resolves the project ID to canonical and table names
    - Fetches meeting data from the database
    - Optionally filters by date range (start_date, end_date)
    - Generates a professional README using LLM
    - Saves README to disk and stores in database
    
    Args:
        request: GenerateReadmeRequest with:
            - project_id: Project identifier (canonical or normalized name)
            - start_date: Optional start date filter (YYYY-MM-DD)
            - end_date: Optional end date filter (YYYY-MM-DD)
        
    Returns:
        dict: Status of README generation including:
            - status: "README generated"
            - project: Canonical project name
            - filepath: Path to saved README file
            - meetings_processed: Number of meetings used
    """
    try:
        postgres_client = PostgresClient()
        
        # Resolve project name (similar to scripts/generate_project_readme.py)
        project_lower = request.project_id.lower().strip()
        projects = postgres_client.get_all_projects()
        
        canonical_name = None
        table_name = None
        
        # Find matching project
        for canonical, normalized in projects:
            if normalized == project_lower or canonical.lower() == project_lower:
                canonical_name = canonical
                table_name = normalized
                break
        
        # Check if table exists directly
        if not table_name and postgres_client.project_table_exists(project_lower):
            canonical_name = request.project_id
            table_name = project_lower
        
        # Partial match fallback
        if not table_name:
            for canonical, normalized in projects:
                if project_lower in normalized or project_lower in canonical.lower():
                    canonical_name = canonical
                    table_name = normalized
                    break
        
        if not table_name:
            raise HTTPException(
                status_code=404,
                detail=f"Project '{request.project_id}' not found"
            )
        
        # Fetch project data
        columns, rows = postgres_client.fetch_project_data(table_name)
        
        if not rows:
            raise HTTPException(
                status_code=404,
                detail=f"No data found for project '{request.project_id}'"
            )
        
        # Apply date filters if provided
        if request.start_date or request.end_date:
            filtered_rows = []
            for row in rows:
                meeting_date = row.get('meeting_date')
                if not meeting_date:
                    continue
                
                if request.start_date and meeting_date < request.start_date:
                    continue
                if request.end_date and meeting_date > request.end_date:
                    continue
                
                filtered_rows.append(row)
            rows = filtered_rows
        
        if not rows:
            raise HTTPException(
                status_code=404,
                detail=f"No data found for project '{request.project_id}' in the specified date range"
            )
        
        # Generate README
        generator = ReadmeGenerator()
        readme_content = generator.generate(
            project_name=canonical_name,
            rows=rows,
            columns=columns
        )
        
        # Save to disk
        filepath = generator.save_to_disk(
            project_name=canonical_name,
            content=readme_content,
            output_dir="readmes"
        )
        
        # Store in database
        try:
            postgres_client.store_readme(
                project_name=canonical_name,
                normalized_name=table_name,
                content=readme_content,
                model="gpt-4o-mini",
                meeting_count=len(rows)
            )
        except Exception as e:
            # Non-fatal error
            pass
        
        return {
            "status": "README generated",
            "project": canonical_name,
            "filepath": filepath,
            "meetings_processed": len(rows)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"README generation failed: {str(e)}")
